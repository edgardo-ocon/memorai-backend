# MemorAI Backend

Este es el backend de la plataforma MemorAI, un sistema que permite recrear recuerdos y sueños con inteligencia artificial generando imágenes, audios y videos emocionales.

## ¿Qué hace?
- Recibe un texto con un recuerdo o sueño.
- Genera una historia emocional (GPT-4)
- Crea una imagen realista (DALL·E o PlaygroundAI)
- Crea una voz emocional (ElevenLabs)
- Une los elementos en un video (simulado)

## Tecnologías utilizadas
- Node.js + Express
- MongoDB Atlas
- OpenAI API
- ElevenLabs API
- Render para despliegue

## Cómo usar
1. Clona el repositorio
2. Crea el archivo `.env` con tus claves
3. Ejecuta `npm install`
4. Inicia con `npm start`

## Despliegue recomendado
Puedes usar [https://render.com](https://render.com) para desplegar el backend fácilmente.

---

Hecho con ❤️ para transformar emociones en experiencias digitales.
